var APP_ID = undefined; //replace with 'amzn1.echo-sdk-ams.app.[your-unique-value-here]';
var https = require('https');
var AlexaSkill = require('./AlexaSkill');
/**
 * URL prefix to download skir resort content from OnTheSnow.com
 */
var urlPrefix = ''
/**
 * SnowGiddy is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var SnowGiddy = function() {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
SnowGiddy.prototype = Object.create(AlexaSkill.prototype);
SnowGiddy.prototype.constructor = SnowGiddy;

SnowGiddy.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("SnowGiddy onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);

    // any session init logic would go here
};

SnowGiddy.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("SnowGiddy onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    getWelcomeResponse(response);
};

SnowGiddy.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
};

SnowGiddy.prototype.intentHandlers = {

    "GetFullReportIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the full report for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetTwentyFourHourSnowIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the twenty four hour snow report for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetSeventyTwoHourSnowIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the seventy two hour snow report for Alta",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetFiveDayForecastIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the five day forecast for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetBaseDepthIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the base depth for Alta",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetSummitDepthIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the summit depth for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetWeatherIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the weather report for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetAvalancheReportIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the avalanche report for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetVisibilityIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the visibility for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetSnowConditionIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the snow condition for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetResortStatusIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the resort status for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetOperatingLiftsIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here are the operating lifts for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetElevationIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the elevation for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetResortOverviewIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the resort overview for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetTerrainOverviewIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the terrain overview for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetContactInfoIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here is the contact info for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "GetLiftTicketPriceIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "Here are the lift ticket prices for Alta.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "SendFullReportIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "I have sent a full report for Alta to your mobile device.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "SendFiveDayForecastIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "I have sent a five day forecast for Alta to your mobile device.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "SendContactInfoIntent": function (intent, session, response) {
      var resortNameSlot = intent.slots.resortName;
      var speechOutput = {
              speech: "I have sent contact info for Alat to your mobile device.",
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
      };
      response.tell(speechOutput);
    },

    "AMAZON.HelpIntent": function (intent, session, response) {
        var speechText = "With Snow Giddy, you can get snow updates and much more for any ski resort." +
            "For example, you could say Sundance Mountain Resort full report, or Sundance Mountain Resort five day forecast, or you can say exit. Now, which resort do you want?";
        var repromptText = "Which resort do you want?";
        var speechOutput = {
            speech: speechText,
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        var repromptOutput = {
            speech: repromptText,
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        response.ask(speechOutput, repromptOutput);
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = {
                speech: "Thank you for using Snow Giddy, enjoy the snow.",
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = {
                speech: "Thank you for using Snow Giddy, have fun shredding.",
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        response.tell(speechOutput);
    },

    "AMAZON.RepeatIntent": function (intent, session, response) {
        var speechOutput = {
              speech: "I will repeat for you."
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        reponse.tell(speechOutput);
    },

    "AMAZON.StartOverIntent": function (intent, session, response) {
        var speechOutput = {
              speech: "I will start all over."
              type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        response.tell(speechOutput);
    }
};

function getWelcomeResponse(response) {
    var cardTitle = "Snow Giddy";
    var repromptText = "With Snow Giddy, you can get snow updates and much more for any ski resort. For example, you could say Sundance Mountain full report, or Sundance Mountain five day forecast, or you can say exit. Now, which resort do you want?";
    var speechText = "<p>Snow Giddy.</p> <p>What resort do you want information for?</p>";
    var cardOutput = "Snow Giddy. What resort do you want information for?";
    var speechOutput = {
        speech: "<speak>" + speechText + "</speak>",
        type: AlexaSkill.speechOutputType.SSML
    };
    var repromptOutput = {
        speech: repromptText,
        type: AlexaSkill.speechOutputType.PLAIN_TEXT
    };
    response.askWithCard(speechOutput, repromptOutput, cardTitle, cardOutput);
}

function handleFullReportRequest(intent, session, response) {
    var resortNameSlot = intent.slots.resortName;
    var repromptText = "With Snow Giddy, you can get snow updates and more for any ski resort. For example, you could say Sundance Mountain full report, or Sundance Mountain five day forecast, or you can say exit. Now, which resort do you want?";
    var resortNames = ["Alta", "Brighton", "Snowbird", "Solitude", "Park City", "Canyons", "Sundance", "Sun Valley", "Brian Head", "Bear Mountain", "Mammoth"
    ];
    var sessionAttributes = {};
    sessionAttributes.index = paginationSize;
    var resort = "";

    if (resortNameSlot && resortNameSlot.value) {
        resortName = new Resort(resortNameSlot.value);
    } else {
        resortName = new Resort();
    }

    var prefixContent = "<p>For " + resortName[resortName.getResort()] + " " + resortName.getResort() + ", </p>";
    var cardContent = "For " + resortName[resortName.getResort()] + " " + resortName.getResort() + ", ";

    var cardTitle = "Full report for " + resortName[resortName.getResort()] + " " + resortName.getResort();

    getJsonFullReportFromOnTheSnow(resortName[resortName.getResort()], resortName.getResort(), function (full_report) {
        var speechText = "",
            i;
        sessionAttributes.text = full_report;
        session.attributes = sessionAttributes;
        if (full_report.length == 0) {
            speechText = "There is a problem connecting to On The Snow at this time. Please try again later.";
            cardContent = speechText;
            response.tell(speechText);
        } else {
            for (i = 0; i < paginationSize; i++) {
                cardContent = cardContent + full_report[i] + " ";
                speechText = "<p>" + speechText + full_report[i] + "</p> ";
            }
            speechText = speechText + "<p>Do you want additional resort information?</p>";
            var speechOutput = {
                speech: "<speak>" + prefixContent + speechText + "</speak>",
                type: AlexaSkill.speechOutputType.SSML
            };
            var repromptOutput = {
                speech: repromptText,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.askWithCard(speechOutput, repromptOutput, cardTitle, cardContent);
        }
    });
}
function handleFullReportRequest(intent, session, response) {
}
function handleTwentyFourHourSnowRequest(intent, session, response) {
}
function handleSeventyTwoHourSnowRequest(intent, session, response) {
}
function handleFiveDayForecastRequest(intent, session, response) {
}
function handleBaseDepthRequest(intent, session, response) {
}
function handleSummitDepthRequest(intent, session, response) {
}
function handleWeatherRequest(intent, session, response) {
}
function handleAvalancheReportRequest(intent, session, response) {
}
function handleVisibilityRequest(intent, session, response) {
}
function handleSnowConditionRequest(intent, session, response) {
}
function handleResortStatusRequest(intent, session, response) {
}
function handleOperatingLiftsRequest(intent, session, response) {
}
function handleElevationRequest(intent, session, response) {
}
function handleResortOverviewRequest(intent, session, response) {
}
function handleTerrainOverviewRequest(intent, session, response) {
}
function handleContactInfoRequest(intent, session, response) {
}
function handleLiftTicketPriceRequest(intent, session, response) {
}
function handleFullReportRequest(intent, session, response) {
}
function handleFiveDayForecastRequest(intent, session, response) {
}
function handleContactInfoRequest(intent, session, response) {
}

function handleNextEventRequest(intent, session, response) {
    var cardTitle = "More events on this day in history",
        sessionAttributes = session.attributes,
        result = sessionAttributes.text,
        speechText = "",
        cardContent = "",
        repromptText = "Do you want to know more about what happened on this date?",
        i;
    if (!result) {
        speechText = "With History Buff, you can get historical events for any day of the year. For example, you could say today, or August thirtieth. Now, which day do you want?";
        cardContent = speechText;
    } else if (sessionAttributes.index >= result.length) {
        speechText = "There are no more events for this date. Try another date by saying <break time = \"0.3s\"/> get events for august thirtieth.";
        cardContent = "There are no more events for this date. Try another date by saying, get events for august thirtieth.";
    } else {
        for (i = 0; i < paginationSize; i++) {
            if (sessionAttributes.index>= result.length) {
                break;
            }
            speechText = speechText + "<p>" + result[sessionAttributes.index] + "</p> ";
            cardContent = cardContent + result[sessionAttributes.index] + " ";
            sessionAttributes.index++;
        }
        if (sessionAttributes.index < result.length) {
            speechText = speechText + " Wanna go deeper in history?";
            cardContent = cardContent + " Wanna go deeper in history?";
        }
    }
    var speechOutput = {
        speech: "<speak>" + speechText + "</speak>",
        type: AlexaSkill.speechOutputType.SSML
    };
    var repromptOutput = {
        speech: repromptText,
        type: AlexaSkill.speechOutputType.PLAIN_TEXT
    };
    response.askWithCard(speechOutput, repromptOutput, cardTitle, cardContent);
}

function getJsonEventsFromWikipedia(day, date, eventCallback) {
    var url = urlPrefix + day + '_' + date;

    https.get(url, function(res) {
        var body = '';

        res.on('data', function (chunk) {
            body += chunk;
        });

        res.on('end', function () {
            var stringResult = parseJson(body);
            eventCallback(stringResult);
        });
    }).on('error', function (e) {
        console.log("Got error: ", e);
    });
}

function parseJson(inputText) {
    // sizeOf (/nEvents/n) is 10
    var text = inputText.substring(inputText.indexOf("\\nEvents\\n")+10, inputText.indexOf("\\n\\n\\nBirths")),
        retArr = [],
        retString = "",
        endIndex,
        startIndex = 0;

    if (text.length == 0) {
        return retArr;
    }

    while(true) {
        endIndex = text.indexOf("\\n", startIndex+delimiterSize);
        var eventText = (endIndex == -1 ? text.substring(startIndex) : text.substring(startIndex, endIndex));
        // replace dashes returned in text from Wikipedia's API
        eventText = eventText.replace(/\\u2013\s*/g, '');
        // add comma after year so Alexa pauses before continuing with the sentence
        eventText = eventText.replace(/(^\d+)/,'$1,');
        eventText = 'In ' + eventText;
        startIndex = endIndex+delimiterSize;
        retArr.push(eventText);
        if (endIndex == -1) {
            break;
        }
    }
    if (retString != "") {
        retArr.push(retString);
    }
    retArr.reverse();
    return retArr;
}

// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    // Create an instance of the HistoryBuff Skill.
    var skill = new SnowGiddy();
    skill.execute(event, context);
};
